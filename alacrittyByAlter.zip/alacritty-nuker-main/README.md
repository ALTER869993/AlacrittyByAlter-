# alacritty-nuker
best &amp; fastest nuker on cord, src.

100% created by aced & dropout.
